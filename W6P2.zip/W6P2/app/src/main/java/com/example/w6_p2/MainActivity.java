package com.example.w6_p2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BtnsFragment btnsfragment = new BtnsFragment();
        DrawableFragment drawablefragment = new DrawableFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_btns, btnsfragment, "btnsfragment").commit();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_drawable, drawablefragment, "drawablefragment").commit();

        btnsfragment.setOnDataTransmissionListener(new BtnsFragment.OnDataTransmissionListener() {
            @Override
            public void dataTransmission(String data) {
                if(data.equals("left")){
                    drawablefragment.leftClicked();
                }
                else if (data.equals("right")){
                    drawablefragment.rightClicked();
                }
            }
        });
    }
}