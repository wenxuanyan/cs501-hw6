package com.example.w6_p2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class BtnsFragment extends Fragment {

    public interface OnDataTransmissionListener {
        public void dataTransmission(String data);
    }

    private Button left;
    private Button right;
    private OnDataTransmissionListener mListener;

    public void setOnDataTransmissionListener (OnDataTransmissionListener mListener) {
        this.mListener = mListener;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View v = inflater.inflate(R.layout.fragment_btns, container, false);

         left = (Button) v.findViewById(R.id.left);
         right = (Button) v.findViewById(R.id.right);

         left.setOnClickListener(new View.OnClickListener() {

             @Override
             public void onClick(View v) {
                 if(mListener != null){
                     mListener.dataTransmission("left");
                 }
             }
         });

         right.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if(mListener != null){
                     mListener.dataTransmission("right");
                 }
             }
         });
         return v;


    }
}