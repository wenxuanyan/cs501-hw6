package com.example.w6_p1;

import android.media.Image;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;


public class fragment_bot extends Fragment {

    private ImageView ivAnimal;
    private TextView tvName;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_bot, container, false);

        ivAnimal = (ImageView) v.findViewById(R.id.ivAnimal);
        tvName = (TextView) v.findViewById(R.id.tvName);

        return v;
    }

    public void setData (int order) {
        switch(order){
            case 0:
                tvName.setText("Bird");
                ivAnimal.setImageResource(R.drawable.bird);
                break;
            case 1:
                tvName.setText("Dog");
                ivAnimal.setImageResource(R.drawable.dog);
                break;
            case 2:
                tvName.setText("Dragon");
                ivAnimal.setImageResource(R.drawable.dragon);
                break;
            case 3:
                tvName.setText("Lion");
                ivAnimal.setImageResource(R.drawable.lion);
                break;
            case 4:
                tvName.setText("Pig");
                ivAnimal.setImageResource(R.drawable.pig);
                break;
        }
    }
}