package com.example.w6_p1;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class fragment_top extends Fragment {

    private ListView lvAnimals;
    private OnDataTransmissionListener mListener;
    private MediaPlayer sound;

    public interface OnDataTransmissionListener {
        public void dataTransmission(int data);
    }

    public void setOnDataTransmissionListener (OnDataTransmissionListener mListener) {
        this.mListener = mListener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_top, container, false);

        sound = MediaPlayer.create(getActivity(), R.raw.brid);

        lvAnimals = (ListView) v.findViewById(R.id.lvAnimals);

        ArrayList<String> animals = new ArrayList<String>();

        animals.add("Bird");
        animals.add("Dog");
        animals.add("Dragon");
        animals.add("Lion");
        animals.add("Pig");

        ArrayAdapter<String> arrayAdaptor = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, animals);

        lvAnimals.setAdapter(arrayAdaptor);
        lvAnimals.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    case 0:
                        sound.release();
                        sound = MediaPlayer.create(getActivity(), R.raw.brid);
                        sound.start();
                        break;
                    case 1:
                        sound.release();
                        sound = MediaPlayer.create(getActivity(), R.raw.dog);
                        sound.start();
                        break;
                    case 2:
                        sound.release();
                        sound = MediaPlayer.create(getActivity(), R.raw.dragon);
                        sound.start();
                        break;
                    case 3:
                        sound.release();
                        sound = MediaPlayer.create(getActivity(), R.raw.lion);
                        sound.start();
                        break;
                    case 4:
                        sound.release();
                        sound = MediaPlayer.create(getActivity(), R.raw.pig);
                        sound.start();
                        break;
                }
                if (mListener != null) {
                    mListener.dataTransmission(i);
                }
            }
        });
        return v;
    }
}