package com.example.w6_p1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragment_top fragment1 = new fragment_top();
        fragment_bot fragment2 = new fragment_bot();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_top, fragment1, "fragment1").commit();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_bot, fragment2, "fragment2").commit();

        fragment1.setOnDataTransmissionListener(new fragment_top.OnDataTransmissionListener() {
            @Override
            public void dataTransmission(int data) {
                fragment2.setData(data);
            }
        });
    }
}